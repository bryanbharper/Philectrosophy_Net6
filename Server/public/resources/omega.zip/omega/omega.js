
var globalPlayerScore = "noOne";
var globalLevelReached = 1;
var canvas = document.getElementById("canvas");
var processing = new Processing(canvas, function (processing) {
    var screenWidth = 750 * (3 / 4);
    var screenHeight = 500 * (3 / 4);
    processing.size(screenWidth, screenHeight);
    processing.background(0xFFF);

    var mouseIsPressed = false;
    processing.mousePressed = function () { mouseIsPressed = true; };
    processing.mouseReleased = function () { mouseIsPressed = false; };

    var keyIsPressed = false;
    processing.keyPressed = function () { keyIsPressed = true; };
    processing.keyReleased = function () { keyIsPressed = false; };

    function getImage(s) {
        var url = "resources/" + s + ".png";
        processing.externals.sketch.imageCache.add(url);
        return processing.loadImage(url);
    }


    // use degrees rather than radians in rotate function
    var rotateFn = processing.rotate;
    processing.rotate = function (angle) {
        rotateFn(processing.radians(angle));
    };


    with (processing) {

        // INSERT MAIN CODE HERE
        // Load Media
        // @pjs preload="resources/bg_imgs/bg_lvl1.png";

        // Ensure Default image display mode is Center 
        imageMode(CENTER);

        /////////////////////////////////////////////////////////////////////////
        //
        //                           Object Constructors
        //
        ////////////////////////////////////////////////////////////////////////
        var Hero = function (x, y, img, invImg) {
            // Properties
            this.x = x;
            this.y = y;
            this.width = 35 * (3 / 4);
            this.height = 32 * (3 / 4);
            this.xSpeed = 0;
            this.ySpeed = 0;
            this.img = img;
            this.invImg = invImg;
            this.imgLights = getImage("spr_ship_light");

            this.playername;
            this.lives = 3;

            this.score = 0;
            this.coins = 0;
            this.numFuel = 0;
            this.numBurger = 0;
            this.health = 1.0;
            this.fuel = 1.0;

            this.astCollide = 0;
            this.lights = 0;

            // Functions
            this.draw = function () {
                imageMode(CENTER);
                this.x += this.xSpeed;
                this.y += this.ySpeed;
                if (this.astCollide === 0) {
                    image(this.img, this.x, this.y, this.size, this.size);
                } else {
                    image(this.invImg, this.x, this.y, this.width, this.height);
                    --this.astCollide;
                }
                if (this.lights === 0) {
                    image(this.img, this.x, this.y, this.width, this.height);
                } else {
                    image(this.imgLights, this.x, this.y, this.width, this.height);
                    --this.lights;
                }
                this.x = constrain(this.x, this.width / 2, width - this.width / 2);
                this.y = constrain(this.y, this.height / 2, height - this.height / 2);
                this.xSpeed = constrain(this.xSpeed, -7, 7);
                this.ySpeed = constrain(this.ySpeed, -7, 7);
                if ((this.x === this.width / 2) || (this.x === width - this.width / 2)) {
                    this.xSpeed = 0;
                }
                if ((this.y === this.height / 2) || (this.y === height - this.height / 2)) {
                    this.ySpeed = 0;
                }
                this.fuel = constrain(this.fuel, 0, 1);
                this.health = constrain(this.health, 0, 1);
            };

            this.up = function () {
                this.ySpeed -= 0.2;
                imageMode(CENTER);
                this.lights = 1;
                image(getImage("spr_steamForward"), this.x - this.width, this.y + this.height / 3, (1 / 5) * 231 * (3 / 4), (1 / 5) * 164) * (3 / 4);
                this.fuel -= 0.002;
            };
            this.down = function () {
                this.ySpeed += 0.2;
                imageMode(CENTER);
                this.lights = 1;
                image(getImage("spr_steamForward"), this.x - this.width, this.y - this.height / 3, (1 / 5) * 231 * (3 / 4), (1 / 5) * 164) * (3 / 4);
                this.fuel -= 0.003
            };
            this.right = function () {
                this.xSpeed += 0.2;
                imageMode(CENTER);
                this.lights = 1;
                image(getImage("spr_steamForward"), this.x - this.width, this.y + this.height / 3, (1 / 5) * 231 * (3 / 4), (1 / 5) * 164 * (3 / 4) * (3 / 4));
                image(getImage("spr_steamForward"), this.x - this.width, this.y - this.height / 3, (1 / 5) * 231 * (3 / 4), (1 / 5) * 164 * (3 / 4));
                this.fuel -= 0.002;
            };
            this.left = function () {
                this.xSpeed -= 0.2;
                imageMode(CENTER);
                this.lights = 1;
                this.fuel -= 0.002;
            };

            this.checkForAsteroidCollision = function (asteroid) {
                if ((asteroid.x >= (this.x - this.width / 2) && asteroid.x <= (this.x + this.width / 2 + asteroid.width / 2)) &&
                    (asteroid.y >= (this.y - this.height / 2) && asteroid.y <= (this.y + this.height / 2 + asteroid.width / 2)) &&
                    (asteroid.active === 1)) {
                    this.astCollide = 5;
                    this.health -= 0.35;
                    asteroid.active = 0;
                    asteroid.collide = 18;
                    snd_explosion.play();
                }
            };
            this.checkForFuelCollect = function (fuel) {
                if ((fuel.x >= (this.x - this.width / 2) && fuel.x <= (this.x + this.width / 2 + fuel.width / 2)) &&
                    (fuel.y >= (this.y - this.height / 2) && fuel.y <= (this.y + this.height / 2 + fuel.height / 2))) {
                    fuel.x = -40;
                    snd_fuel.play();
                    this.fuel += 0.5;
                    ++this.numFuel;
                }
            };
            this.checkForBurgerCollect = function (burger) {
                if ((burger.x >= (this.x - this.width / 2) && burger.x <= (this.x + this.width / 2 + burger.width / 2)) &&
                    (burger.y >= (this.y - this.height / 2) && burger.y <= (this.y + this.height / 2 + burger.height / 2))) {
                    burger.x = -40;
                    snd_burger.play();
                    this.health += 0.5;
                    ++this.numBurger;
                }
            };
            this.checkForCoinCollect = function (coin) {
                if ((coin.x >= (this.x - this.width / 2) && coin.x <= (this.x + this.width / 2 + coin.size / 2)) &&
                    (coin.y >= (this.y - this.height / 2) && coin.y <= (this.y + this.height / 2 + coin.size / 2))) {
                    coin.x = -40;
                    snd_coin.play();
                    ++this.coins;

                }

            };
        };

        var Asteroid = function (x, y, spin) {
            this.x = x;
            this.y = y;
            this.speed = 1;
            this.spin = spin;
            this.collide = 0;
            this.active = 1;
            this.imgNum = random(2);
            if (this.imgNum >= 1) {
                this.img = getImage("spr_asteroid_1");
                this.width = 48 * (3 / 4);
                this.height = 56 * (3 / 4);
            } else {
                this.img = getImage("spr_asteroid_2");
                this.width = 47 * (3 / 4);
                this.height = 45 * (3 / 4);
            }

            this.draw = function () {

                if (this.collide > 16) {
                    this.img = getImage("explo/spr_redExplo1");
                    --this.collide;
                } else if ((this.collide <= 16) && (this.collide > 14)) {
                    this.img = getImage("explo/spr_redExplo2");
                    --this.collide;
                } else if ((this.collide <= 14) && (this.collide > 12)) {
                    this.img = getImage("explo/spr_redExplo3");
                    --this.collide;
                } else if ((this.collide <= 12) && (this.collide > 10)) {
                    this.img = getImage("explo/spr_redExplo4");
                    --this.collide;
                } else if ((this.collide <= 10) && (this.collide > 8)) {
                    this.img = getImage("explo/spr_redExplo5");
                    --this.collide;
                } else if ((this.collide <= 8) && (this.collide > 6)) {
                    this.img = getImage("explo/spr_redExplo6");
                    --this.collide;
                } else if ((this.collide <= 6) && (this.collide > 4)) {
                    this.img = getImage("explo/spr_redExplo7");
                    --this.collide;
                } else if ((this.collide <= 4) && (this.collide > 2)) {
                    this.img = getImage("explo/spr_redExplo8");
                    --this.collide;
                } else if ((this.collide <= 2) && (this.collide > 0)) {
                    this.x = -40;
                    if (this.imgNum === 1) {
                        this.img = getImage("spr_asteroid_1");
                    } else {
                        this.img = getImage("spr_asteroid_2");
                    }
                    --this.collide;
                }
                imageMode(CENTER);
                image(this.img, 0, 0, this.width, this.height);
            };
        };

        var Fuel = function (x, y) {
            this.x = x;
            this.y = y;
            this.speed = 1.5;
            this.width = 13 * (3 / 4);
            this.height = 43 * (3 / 4);
            this.img = getImage("spr_fuel");
            this.draw = function () {
                imageMode(CENTER);
                image(this.img, this.x, this.y, this.width, this.height);
            };
        };

        var Burger = function (x, y) {
            this.x = x;
            this.y = y;
            this.speed = 1.5;
            this.width = 38 * (3 / 4);
            this.height = 20 * (3 / 4);
            this.img = getImage("spr_burger");
            this.draw = function () {
                imageMode(CENTER);
                image(this.img, this.x, this.y, this.width, this.height);
            };
        };

        var Coin = function (x, y) {
            this.x = x;
            this.y = y;
            this.speed = 1.7;
            this.size = 20;
            this.timer = 16;
            this.draw = function () {
                if (this.timer > 14) {
                    this.img = getImage("coins/spr_coin_1");
                    --this.timer;
                } else if ((this.timer <= 14) && (this.timer > 12)) {
                    this.img = getImage("coins/spr_coin_2");
                    --this.timer;
                } else if ((this.timer <= 12) && (this.timer > 10)) {
                    this.img = getImage("coins/spr_coin_3");
                    --this.timer;
                } else if ((this.timer <= 10) && (this.timer > 8)) {
                    this.img = getImage("coins/spr_coin_4");
                    --this.timer;
                } else if ((this.timer <= 8) && (this.timer > 6)) {
                    this.img = getImage("coins/spr_coin_5");
                    --this.timer;
                } else if ((this.timer <= 6) && (this.cotimerllide > 4)) {
                    this.img = getImage("coins/spr_coin_6");
                    --this.timer;
                } else if ((this.timer <= 4) && (this.timer > 2)) {
                    this.img = getImage("coins/spr_coin_7");
                    --this.timer;
                } else if ((this.timer <= 2) && (this.timer > 0)) {
                    this.img = getImage("coins/spr_coin_8");
                    --this.timer;
                } else {
                    this.timer = 16;
                }
                imageMode(CENTER);
                image(this.img, this.x, this.y, this.size, this.size);
            };
        };

        var Planet = function (x, y, level) {
            this.x = x;
            this.y = y;
            this.size = 180 * (3 / 4);
            this.level = level;
            this.img = planetImgs[level];
            this.name = planetNames[level];
            this.draw = function () {
                imageMode(CENTER);
                image(this.img, this.x, this.y, this.size, this.size);
            };
        };

        var gameSound = function (src) {
            this.sound = document.createElement("audio");
            this.sound.src = src;
            this.sound.setAttribute("preload", "auto");
            this.sound.setAttribute("controls", "none");
            this.sound.style.display = "none";
            document.body.appendChild(this.sound);
            this.play = function () {
                this.currentTime = 0;
                this.sound.play();
            }
            this.stop = function () {
                this.sound.pause();
            }
        }

        ////////////////////////////////////////////////////////////////////////
        //
        //                           Global Variables 
        //
        ////////////////////////////////////////////////////////////////////////
        var gameMode = "Main Menu";
        var backX = 0;
        var bg_img = getImage("bg_imgs/bg_level1");
        var bg_lvl1 = bg_img;
        var bg_lvl2 = getImage("bg_imgs/bg_level2");
        var bg_lvl3 = getImage("bg_imgs/bg_level3");
        var bg_lvl4 = getImage("bg_imgs/bg_level4");
        var bg_lvl5 = getImage("bg_imgs/bg_level5");
        var bg_lvl6 = getImage("bg_imgs/bg_level6");
        var bg_lvl7 = getImage("bg_imgs/bg_level7");

        var f = createFont("Arial");
        textFont(f);
        var fuelCount = 0;
        var level = 1;
        var lvlBonus = 0;
        var coinBonus = 0;
        var fuelBonus = 0;
        var burgerBonus = 0;
        var healthBonus = 0;
        var scoreIsCalculated = false;
        /*
        The legnth of the level is defined by the number of coints: L = coinNum * coinInterval + coinOffset.
        
        It is desired that for each additional item, its number, interval, and offset are such that the 
        cover approximately the same length. 
        
        The code below takes each item interval and offset as constant, and finds the closest integer 
        for a given item number that will result in approximately the same length. 
        */
        var coinInterval = 200;
        var coinOffset = width;
        var coinNum = 40;

        var fuelInverval = 800;
        var fuelOffset = width + 200;
        var fuelNum = round((coinNum * coinInterval + coinOffset - fuelOffset) / fuelInverval);

        var burgerInverval = 863;
        var burgerOffset = 1500;
        var burgerNum = round((coinNum * coinInterval + coinOffset - burgerOffset) / burgerInverval);

        var asteroidIntverval = 80;
        var asteroidOffset = 450;
        var asteroidNum = round((2 * (coinNum * coinInterval + coinOffset) - asteroidOffset) / asteroidIntverval);

        /////////////////////////////////////////////////////////////////////////
        //
        //                                 Arrays 
        //
        ////////////////////////////////////////////////////////////////////////
        var asteroids = [];
        var fuelCans = [];
        var burgers = [];
        var spins = [];
        var coins = [];
        var planetImgs = [getImage("spr_pln_terra"), getImage("spr_pln_terra"), getImage("spr_pln_aclite"), getImage("spr_pln_oytania"),
        getImage("spr_pln_paynus"), getImage("spr_pln_drov"), getImage("spr_pln_piotov"), getImage("spr_pln_thonoe")];
        var planetNames = ["Terra", "Terra", "Aclite", "Oytania", "Paynus", "Drov", "Piotov", "Thonos"];
        /////////////////////////////////////////////////////////////////////////
        //
        //                           Object Instances 
        //
        ////////////////////////////////////////////////////////////////////////
        var hero = new Hero(width / 2, height / 2, getImage("spr_ship"), getImage("spr_ship_inv"));
        var planet = new Planet(4000, height / 2, level);
        for (var i = 0; i < asteroidNum; i++) {
            asteroids.push(new Asteroid(i * asteroidIntverval + asteroidOffset, random(5, height - 5), 0)); //asteroids
            spins.push(random(-4, 4));
        }
        for (var i = 0; i < fuelNum; i++) {
            fuelCans.push(new Fuel(i * fuelInverval + fuelOffset, random(5, height - 5))); //fuelCans
        }
        for (var i = 0; i < burgerNum; i++) {
            burgers.push(new Burger(i * burgerInverval + burgerOffset, random(5, height - 5))); //fuelCans
        }
        for (var i = 0; i < coinNum; i++) {
            coins.push(new Coin(i * coinInterval + coinOffset, random(5, height - 5))); //coins
        }

        var snd_coin = new gameSound("resources/soundFX/Pickup_Coin.wav");
        var snd_explosion = new gameSound("resources/soundFX/Explosion.wav");
        var snd_fuel = new gameSound("resources/soundFX/Jump.wav");
        var snd_burger = new gameSound("resources/soundFX/Randomize3.wav");
        var music_lvlComplete = new gameSound("resources/music/music_lvlComplete.mp3");
        var music_inGame = new gameSound("resources/music/music_level1.mp3");
        var music_menu = new gameSound("resources/music/music_menu.mp3");
        /////////////////////////////////////////////////////////////////////////
        //
        //                             Functions
        //
        /////////////////////////////////////////////////////////////////////////

        var replay = function () {
            if (keyIsPressed && keyCode === 0) {
                ++level;
                globalLevelReached = level;
                newMusic = 1;
                ////////  Reset Fuels, and Asteroids, etc.//////////
                planet = new Planet(4000, height / 2, level);
                for (var i = 0; i < asteroidNum; i++) {
                    asteroids[i].x = i * asteroidIntverval + asteroidOffset;
                    spins[i] = random(-4, 4);
                }
                for (var i = 0; i < fuelNum; i++) {
                    fuelCans[i].x = i * fuelInverval + fuelOffset;
                }
                for (var i = 0; i < burgerNum; i++) {
                    burgers[i].x = i * burgerInverval + burgerOffset;
                }
                for (var i = 0; i < coinNum; i++) {
                    coins[i].x = i * coinInterval + coinOffset;
                }
                planet = new Planet(coins[coins.length - 1].x + 100, height / 2, level);
                // Reset Hero Properties
                hero.health = 1.0;
                hero.fuel = 1.0;
                hero.coins = 0;
                hero.numFuel = 0;
                hero.numBurger = 0;
                hero.x = width / 3;
                hero.y = height / 2;
                scoreIsCalculated = false;
                // Game Mode Decisions   
                if (gameMode === "Game Over") {
                    level = 1;
                    hero.score = 0;
                    gameMode = "Main Menu";
                    planet = new Planet(coins[coins.length - 1].x + 100, height / 2, level);
                } else {
                    music_lvlComplete.stop();
                    newMusic = 1;
                    gameMode = "Play Game";
                }
            } // End If Key is Pressed
        }; // End Replay()

        var healthBar = function () {
            rectMode(CORNER);
            stroke(0, 0, 0);
            fill(252, 252, 252);
            rect(40, 5, 125, 15);
            stroke(51, 255, 0);
            fill(100 / hero.health, 255 * hero.health, 0);
            rect(40 + 2, 5 + 2, 125 * hero.health - 4, 15 - 4);
            imageMode(CENTER);
            image(getImage("spr_burger"), 40 / 2, 15 / 2 + 5, (2 / 3) * 38, (2 / 3) * 20);
        };

        var fuelBar = function () {
            rectMode(CORNER);
            stroke(0, 0, 0);
            fill(252, 252, 252);
            rect(width - 145, 5, 125, 15);
            stroke(51, 255, 0);
            fill(100 / hero.fuel, 0, 255 * hero.fuel);
            rect(width - 145 + 2, 5 + 2, 125 * hero.fuel - 4, 15 - 2);
            imageMode(CENTER);
            image(getImage("spr_fuel"), width - 10, 17, (2 / 3) * 13, (2 / 3) * 43);
        };


        var calcScore = function () {
            if (!scoreIsCalculated) {
                // Level Bonus
                if (gameMode === 'Level Complete') {
                    lvlBonus = 100;
                }
                // Coin Score
                coinBonus = hero.coins * 10;
                // Fuel Bonus
                fuelBonus = round(hero.fuel * 100);

                // Health Bonus
                healthBonus = round(100 * hero.health);

                hero.score = hero.score + coinBonus + lvlBonus + fuelBonus + healthBonus;
                globalPlayerScore = hero.score;

                if (gameMode === "Game Over") {
                    globalLevelReached = level;
                } else {
                    globalLevelReached = level + 1;
                }

                scoreIsCalculated = true;
            }
            textAlign(CENTER);
            textSize(18);
            fill(255, 255, 255);
            if (gameMode === "Level Complete") {
                text("Level Bonus: +" + lvlBonus, width / 2, 0.25 * height);
                text("Coins: +" + coinBonus, width / 2, 0.3 * height);
                text("Fuel Bonus: +" + fuelBonus, width / 2, 0.35 * height);
                text("Health Bonus: +" + healthBonus, width / 2, 0.4 * height);
                textSize(24);
                fill(255, 0, 0);
                text("Total Score:" + hero.score, width / 2, 0.55 * height);
            } else {
                text("Final Score: " + hero.score, width / 2, 200);
                text("Level Reached: " + level, width / 2, 230);
            }
        };

        /////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////
        //
        //                                 Draw
        //
        ////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////
        var draw = function () {
            background(36, 61, 142);
            /////////////////////////////////////////////////////////////////////////////////////
            ///////////////////////////////   OPENING MENU      ////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////
            if (gameMode === "Main Menu") {
                music_menu.play();
                // Display Background 
                imageMode(CORNER);
                image(bg_img, backX, 0, 1600, screenHeight);
                --backX;
                // Display Planet
                pln_width = 150 * (3 / 4);
                pln_height = 150 * (3 / 4);
                imageMode(CENTER);
                image(getImage("spr_pln_terra"), width / 2, height / 2, pln_width, pln_height);
                // Display Ship
                image(getImage("spr_ship"), width / 3 + 25, height / 3 + 25, 50 * (3 / 4), 50 * (3 / 4));

                // Title
                textSize(100);
                textAlign(CENTER, CENTER);
                fill(247, 35, 35);
                text("Omega", width / 2, 0.2 * height);
                // Menu Items
                fill(247, 247, 247);
                textSize(30);
                text("Hit Space to Play", width / 2, 0.8 * height);
                textSize(24);
                fill(255, 255, 255);

                if (keyIsPressed && keyCode === 0) {
                    newMusic = 1;
                    gameMode = "Play Game";
                }
            }

            ////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////   PLAY GAME      //////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////
            if (gameMode === "Play Game") {
                music_menu.stop();
                music_lvlComplete.stop();
                if (newMusic === 1) {
                    switch (level) {
                        case 1:
                            music_inGame.sound.src = "resources/music/music_level1.mp3";
                            bg_img = bg_lvl1;
                            break;
                        case 2:
                            music_inGame.sound.src = "resources/music/music_level2.mp3";
                            bg_img = bg_lvl2;
                            break;
                        case 3:
                            music_inGame.sound.src = "resources/music/music_level3.mp3";
                            bg_img = bg_lvl3;
                            break;
                        case 4:
                            music_inGame.sound.src = "resources/music/music_level4.mp3";
                            bg_img = bg_lvl4;
                            break;
                        case 5:
                            music_inGame.sound.src = "resources/music/music_level5.mp3";
                            bg_img = bg_lvl5;
                            break;
                        case 6:
                            music_inGame.sound.src = "resources/music/music_level6.mp3";
                            bg_img = bg_lvl6;
                            break;
                        case 7:
                            music_inGame.sound.src = "resources/music/music_level7.mp3";
                            bg_img = bg_lvl7;
                            break;
                        default:
                            music_inGame.sound.src = "resources/music/music_level1.mp3";
                            bg_img = bg_lvl1;
                    }
                    newMusic = 0;
                }
                music_inGame.play();


                imageMode(CORNER);
                image(bg_img, 0, 0, 1600, screenHeight);
                //player//
                if (keyIsPressed && keyCode === UP) {
                    hero.up();
                }
                if (keyIsPressed && keyCode === DOWN) {
                    hero.down();
                }
                if (keyIsPressed && keyCode === RIGHT) {
                    hero.right();;
                }
                if (keyIsPressed && keyCode === LEFT) {
                    hero.left();
                }

                hero.draw();

                ///////// Asteroids /////////////
                for (var i = 0; i < asteroids.length; i++) {
                    pushMatrix();
                    translate(asteroids[i].x, asteroids[i].y);
                    rotate(asteroids[i].spin);
                    asteroids[i].draw();
                    popMatrix();
                    hero.checkForAsteroidCollision(asteroids[i]);
                    asteroids[i].x -= (1 / 4) * level * asteroids[i].speed + (3 / 4);
                    asteroids[i].spin += spins[i];
                }
                /////////  Fuels    ////////////
                for (var i = 0; i < fuelCans.length; i++) {
                    fuelCans[i].draw();
                    hero.checkForFuelCollect(fuelCans[i]);
                    fuelCans[i].x -= fuelCans[i].speed;
                }
                ////////  Burgers    ////////////
                for (var i = 0; i < burgers.length; i++) {
                    burgers[i].draw();
                    hero.checkForBurgerCollect(burgers[i]);
                    burgers[i].x -= burgers[i].speed;
                }
                /////////  Coins    ////////////
                for (var i = 0; i < coins.length; i++) {
                    coins[i].draw();
                    hero.checkForCoinCollect(coins[i]);
                    coins[i].x -= coins[i].speed;
                }

                healthBar();
                fuelBar();
                planet.x = coins[coins.length - 1].x + 100;
                planet.img = planetImgs[level];
                planet.draw();

                //////// Game Over /////////
                if (hero.health <= 0 || hero.fuel <= 0) {
                    gameMode = "Game Over";
                }


                //////// Level  /////////
                textAlign(CORNER, CORNER);
                textSize(18);
                fill(255, 255, 255);
                text("Sol System: " + planet.name, 20, height - 20);
                ///// Level Complete ////// 
                if ((planet.x <= 0) ||
                    ((hero.x >= (planet.x - planet.size / 2)) && (hero.x <= (planet.x + planet.size / 2)) && (hero.y <= (planet.y + planet.size / 2)) && (hero.y >= (planet.y - planet.size / 2)))) {
                    gameMode = "Level Complete";
                }
            }

            /////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////   LEVEL COMPLETE     ////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////
            if (gameMode === "Level Complete") {
                music_inGame.stop();
                music_lvlComplete.play();
                imageMode(CORNER);
                image(bg_img, 0, 0, 1600, screenHeight);
                /////// Calculate and Dsiplay Score ////////
                calcScore();
                ////////// Reset ////////////   
                if (level >= 7) {
                    textAlign(CENTER);
                    textSize(48);
                    fill(255, 0, 0);
                    text("Game Complete!", width / 2, 0.15 * height);
                    text("Return to Main Menu\n [space]", width / 2, height * 0.75);
                    if (keyIsPressed && keyCode === 0) {
                        gameMode = 0;
                    }
                } else {
                    textAlign(LEFT);
                    textSize(36);
                    fill(255, 0, 0);
                    text("Level Complete!", width / 4, 0.15 * height);
                    textAlign(CENTER);
                    textSize(30);
                    fill(255, 255, 255);
                    text("Continue to Level " + (level + 1) + "\n [space]", width / 2, height * 0.75);
                    replay();
                }

            }
            /////////////////////////////////////////////////////////////////////////////////////
            ////////////////////////////////   GAME OVER      ///////////////////////////////////
            ////////////////////////////////////////////////////////////////////////////////////
            if (gameMode === "Game Over") {
                music_inGame.stop();
                music_menu.play();
                imageMode(CORNER);
                image(bg_img, 0, 0, 1600, screenHeight);
                imageMode(CENTER);
                textAlign(CENTER, CENTER);
                textSize(54);
                fill(26, 25, 25);
                text("Game Over", width / 2, 159);
                fill(255, 0, 0);
                text("Game Over", width / 2, 161);
                textSize(23);
                fill(233, 232, 237);
                text("Play again?\n(space)", width / 2, 238 + 50);
                fill(9, 0, 255);
                text("Play again?\n(space)", width / 2, 237 + 50);
                hero.health = 0;

                healthBar();
                fuelBar();

                //////// Score and Level /////////
                calcScore();

                replay();
            }

        };

    }
    if (typeof draw !== 'undefined') processing.draw = draw;
});

